﻿using ShoppingCart.Views;
using Xamarin.Forms;

namespace ShoppingCart
{
    public class App
    {
        public static Page GetMainPage()
        {
            return new MainPage();
        }
    }
}